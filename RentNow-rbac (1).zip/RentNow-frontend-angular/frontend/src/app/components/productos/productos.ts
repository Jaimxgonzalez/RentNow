import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth';
import { HasPermisoDirective } from '../../directives/has-access';

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [RouterLink, HasPermisoDirective],
  styleUrl: './productos.css',
  templateUrl: './productos.html',
})
export class ProductosComponent {
  auth = inject(AuthService);
}
