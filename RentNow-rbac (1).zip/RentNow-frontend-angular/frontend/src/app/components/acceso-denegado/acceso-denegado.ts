import { Component, inject } from '@angular/core';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-acceso-denegado',
  standalone: true,
  imports: [RouterLink],
  template: `
    <div class="container text-center my-5">
      <h1 class="display-4">403</h1>
      <h2>Acceso denegado</h2>
      <p class="text-muted">Tu rol no tiene permiso para ver esta página.</p>
      <a class="btn btn-primary" [routerLink]="auth.rutaInicial()">Volver al inicio</a>
    </div>
  `,
})
export class AccesoDenegadoComponent {
  auth = inject(AuthService);
}
