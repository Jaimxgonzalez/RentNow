import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../services/auth';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class LoginComponent {
  private auth = inject(AuthService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);

  credentials = { correo: '', contrasena: '' };
  errorMessage = '';
  cargando = false;

  onLogin() {
    this.errorMessage = '';
    this.cargando = true;
    this.auth.login(this.credentials).subscribe({
      next: () => {
        this.cargando = false;
        // Si venía de una ruta protegida vuelve allí; si no, a la pantalla de su rol.
        const volver = this.route.snapshot.queryParamMap.get('returnUrl');
        this.router.navigateByUrl(volver && volver.startsWith('/') ? volver : this.auth.rutaInicial());
      },
      error: (err) => {
        this.cargando = false;
        this.errorMessage =
          err?.status === 400 || err?.status === 401
            ? 'Correo o contraseña incorrectos.'
            : 'No se pudo iniciar sesión. Intenta de nuevo.';
      },
    });
  }
}
