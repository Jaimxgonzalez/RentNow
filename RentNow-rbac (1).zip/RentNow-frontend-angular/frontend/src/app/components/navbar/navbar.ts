import { Component, inject } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../services/auth';
import { HasPermisoDirective } from '../../directives/has-access';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive, HasPermisoDirective],
  template: `
    @if (auth.usuario(); as u) {
      <nav class="navbar navbar-expand navbar-dark bg-dark px-3">
        <a class="navbar-brand" [routerLink]="auth.rutaInicial()">RentNow</a>
        <ul class="navbar-nav me-auto">
          <li class="nav-item" *appHasPermiso="'productos:ver'">
            <a class="nav-link" routerLink="/productos" routerLinkActive="active">Catálogo</a>
          </li>
          <li class="nav-item" *appHasPermiso="'productos:gestionar-propios'">
            <a class="nav-link" routerLink="/mis-productos" routerLinkActive="active">Mis productos</a>
          </li>
          <li class="nav-item" *appHasPermiso="'admin:usuarios'">
            <a class="nav-link" routerLink="/admin-dashboard" routerLinkActive="active">Administración</a>
          </li>
        </ul>
        <span class="navbar-text me-3">{{ u.nombre }} · <span class="badge bg-secondary">{{ u.rol }}</span></span>
        <button class="btn btn-outline-light btn-sm" (click)="salir()">Cerrar sesión</button>
      </nav>
    }
  `,
})
export class NavbarComponent {
  auth = inject(AuthService);
  private router = inject(Router);

  salir(): void {
    this.auth.logout().subscribe(() => this.router.navigate(['/login']));
  }
}
