import { Routes } from '@angular/router';
import { LoginComponent } from './components/login/login';
import { ProductosComponent } from './components/productos/productos';
import { MisProductosComponent } from './components/mis-productos/mis-productos';
import { AdminDashboardComponent } from './components/admin-dashboard/admin-dashboard';
import { AccesoDenegadoComponent } from './components/acceso-denegado/acceso-denegado';
import { authGuard, guestGuard } from './guards/auth-guard';
import { roleGuard } from './guards/role-guard';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },

  { path: 'login', component: LoginComponent, canActivate: [guestGuard] },

  // Catálogo: cualquier rol autenticado
  {
    path: 'productos',
    component: ProductosComponent,
    canActivate: [roleGuard],
    data: { permisos: ['productos:ver'] },
  },

  // Arrendador (y administrador)
  {
    path: 'mis-productos',
    component: MisProductosComponent,
    canActivate: [roleGuard],
    data: { roles: ['arrendador', 'administrador'], permisos: ['productos:gestionar-propios'] },
  },

  // Solo administrador
  {
    path: 'admin-dashboard',
    component: AdminDashboardComponent,
    canActivate: [roleGuard],
    data: { roles: ['administrador'] },
  },

  { path: 'acceso-denegado', component: AccesoDenegadoComponent, canActivate: [authGuard] },

  { path: '**', redirectTo: 'login' },
];
