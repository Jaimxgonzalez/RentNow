import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './services/auth';

/**
 * - Envía la cookie de sesión de Django en cada petición (withCredentials).
 * - 401: la sesión expiró -> limpia estado y manda al login.
 * - 403: el backend rechazó el permiso -> pantalla de acceso denegado.
 */
export const sessionInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  return next(req.clone({ withCredentials: true })).pipe(
    catchError((err: HttpErrorResponse) => {
      const esLogin = req.url.endsWith('/login/');
      if (err.status === 401 && !esLogin) {
        auth.limpiar();
        router.navigate(['/login'], { queryParams: { returnUrl: router.url } });
      } else if (err.status === 403) {
        router.navigate(['/acceso-denegado']);
      }
      return throwError(() => err);
    })
  );
};
