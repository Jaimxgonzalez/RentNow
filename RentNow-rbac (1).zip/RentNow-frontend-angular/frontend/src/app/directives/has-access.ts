import { Directive, TemplateRef, ViewContainerRef, effect, inject, input } from '@angular/core';
import { AuthService } from '../services/auth';
import { Permiso, Rol } from '../models/rbac';

/**
 * Muestra el elemento solo si el usuario tiene el rol o el permiso.
 *   <button *appHasPermiso="'productos:publicar'">Publicar</button>
 *   <a *appHasRol="['administrador','arrendador']">...</a>
 */
@Directive({ selector: '[appHasPermiso]', standalone: true })
export class HasPermisoDirective {
  private tpl = inject(TemplateRef<unknown>);
  private vcr = inject(ViewContainerRef);
  private auth = inject(AuthService);
  appHasPermiso = input.required<Permiso | Permiso[]>();

  constructor() {
    effect(() => {
      const req = this.appHasPermiso();
      const lista = Array.isArray(req) ? req : [req];
      this.auth.permisos(); // dependencia reactiva
      this.vcr.clear();
      if (this.auth.tienePermiso(...lista)) this.vcr.createEmbeddedView(this.tpl);
    });
  }
}

@Directive({ selector: '[appHasRol]', standalone: true })
export class HasRolDirective {
  private tpl = inject(TemplateRef<unknown>);
  private vcr = inject(ViewContainerRef);
  private auth = inject(AuthService);
  appHasRol = input.required<Rol | Rol[]>();

  constructor() {
    effect(() => {
      const req = this.appHasRol();
      const lista = Array.isArray(req) ? req : [req];
      this.auth.rol();
      this.vcr.clear();
      if (this.auth.tieneRol(...lista)) this.vcr.createEmbeddedView(this.tpl);
    });
  }
}
