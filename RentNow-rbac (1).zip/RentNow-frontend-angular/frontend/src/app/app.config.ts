import { ApplicationConfig, provideAppInitializer, inject, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { firstValueFrom } from 'rxjs';
import { routes } from './app.routes';
import { sessionInterceptor } from './interceptors';
import { AuthService } from './services/auth';

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(withInterceptors([sessionInterceptor])),
    // Al arrancar, valida la sesión con el backend (el rol guardado en el navegador no es de fiar).
    provideAppInitializer(() => {
      const auth = inject(AuthService);
      return auth.autenticado() ? firstValueFrom(auth.refrescarSesion()) : Promise.resolve();
    }),
  ],
};
