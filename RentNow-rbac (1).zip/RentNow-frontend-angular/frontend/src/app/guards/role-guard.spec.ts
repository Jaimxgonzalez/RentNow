import { TestBed } from '@angular/core/testing';
import { ActivatedRouteSnapshot, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { provideRouter } from '@angular/router';
import { provideHttpClient } from '@angular/common/http';
import { roleGuard } from './role-guard';
import { AuthService } from '../services/auth';
import { Usuario } from '../models/rbac';

function run(roles: any, permisos: any, usuario: Usuario | null) {
  TestBed.configureTestingModule({ providers: [provideRouter([]), provideHttpClient()] });
  const auth = TestBed.inject(AuthService);
  (auth as any)._usuario.set(usuario);
  const route = { data: { roles, permisos } } as unknown as ActivatedRouteSnapshot;
  const state = { url: '/x' } as RouterStateSnapshot;
  const res = TestBed.runInInjectionContext(() => roleGuard(route, state));
  return { res, router: TestBed.inject(Router) };
}

describe('roleGuard', () => {
  beforeEach(() => sessionStorage.clear());

  it('sin sesión redirige a /login', () => {
    const { res, router } = run(['administrador'], undefined, null);
    expect(router.serializeUrl(res as UrlTree)).toContain('/login');
  });
  it('rol permitido pasa', () => {
    expect(run(['administrador'], undefined, { id: 1, nombre: 'a', rol: 'administrador' }).res).toBe(true);
  });
  it('rol no permitido va a /acceso-denegado', () => {
    const { res, router } = run(['administrador'], undefined, { id: 1, nombre: 'a', rol: 'usuario' });
    expect(router.serializeUrl(res as UrlTree)).toBe('/acceso-denegado');
  });
  it('permiso concedido pasa', () => {
    expect(run(undefined, ['productos:publicar'], { id: 1, nombre: 'a', rol: 'arrendador' }).res).toBe(true);
  });
  it('permiso no concedido se rechaza', () => {
    expect(run(undefined, ['productos:publicar'], { id: 1, nombre: 'a', rol: 'arrendatario' }).res).not.toBe(true);
  });
});
