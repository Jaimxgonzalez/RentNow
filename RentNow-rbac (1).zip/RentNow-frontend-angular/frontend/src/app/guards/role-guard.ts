import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../services/auth';
import { Permiso, Rol } from '../models/rbac';

/**
 * Autoriza por rol y/o permiso. Uso en rutas:
 *   data: { roles: ['administrador'] }            // basta con uno de los roles
 *   data: { permisos: ['productos:publicar'] }    // se requieren todos
 */
export const roleGuard: CanActivateFn = (route, state) => {
  const auth = inject(AuthService);
  const router = inject(Router);

  if (!auth.autenticado()) {
    return router.createUrlTree(['/login'], { queryParams: { returnUrl: state.url } });
  }

  const roles = (route.data['roles'] as Rol[] | undefined) ?? [];
  const permisos = (route.data['permisos'] as Permiso[] | undefined) ?? [];

  const okRol = roles.length === 0 || auth.tieneRol(...roles);
  const okPermiso = permisos.length === 0 || auth.tienePermiso(...permisos);

  return okRol && okPermiso ? true : router.createUrlTree(['/acceso-denegado']);
};
