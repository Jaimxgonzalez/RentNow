/**
 * Modelo RBAC del frontend.
 *
 * Los nombres de rol coinciden con la tabla `roles` de la base de datos
 * (administrador, arrendador, arrendatario, usuario).
 *
 * IMPORTANTE: esto solo controla qué ve y a qué rutas navega el usuario (UX).
 * La seguridad real la debe imponer el backend en cada endpoint.
 */
export type Rol = 'administrador' | 'arrendador' | 'arrendatario' | 'usuario';

export type Permiso =
  | 'productos:ver'
  | 'productos:alquilar'
  | 'productos:publicar'
  | 'productos:gestionar-propios'
  | 'admin:usuarios'
  | 'admin:reportes';

export const ROLES: readonly Rol[] = ['administrador', 'arrendador', 'arrendatario', 'usuario'];

export const PERMISOS_POR_ROL: Record<Rol, readonly Permiso[]> = {
  administrador: [
    'productos:ver',
    'productos:alquilar',
    'productos:publicar',
    'productos:gestionar-propios',
    'admin:usuarios',
    'admin:reportes',
  ],
  arrendador: ['productos:ver', 'productos:publicar', 'productos:gestionar-propios'],
  arrendatario: ['productos:ver', 'productos:alquilar'],
  usuario: ['productos:ver'],
};

/** Ruta a la que se envía a cada rol tras iniciar sesión. */
export const RUTA_INICIAL_POR_ROL: Record<Rol, string> = {
  administrador: '/admin-dashboard',
  arrendador: '/mis-productos',
  arrendatario: '/productos',
  usuario: '/productos',
};

export interface Usuario {
  id: number;
  nombre: string;
  rol: Rol;
}

/** Normaliza lo que mande el backend ("Administrador", "ADMIN", etc.) a un Rol válido. */
export function normalizarRol(valor: unknown): Rol | null {
  if (typeof valor !== 'string') return null;
  const v = valor.trim().toLowerCase();
  if (v === 'admin') return 'administrador';
  return (ROLES as readonly string[]).includes(v) ? (v as Rol) : null;
}
