import { Injectable, computed, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, map, of, tap } from 'rxjs';
import { Permiso, PERMISOS_POR_ROL, RUTA_INICIAL_POR_ROL, Rol, Usuario, normalizarRol } from '../models/rbac';
import { environment } from '../../environments/environment';

const STORAGE_KEY = 'rentnow_user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private apiUrl = environment.apiUrl;

  /** Usuario actual (null si no hay sesión). */
  private readonly _usuario = signal<Usuario | null>(this.leerGuardado());
  readonly usuario = this._usuario.asReadonly();
  readonly autenticado = computed(() => this._usuario() !== null);
  readonly rol = computed<Rol | null>(() => this._usuario()?.rol ?? null);
  readonly permisos = computed<readonly Permiso[]>(() => {
    const r = this.rol();
    return r ? PERMISOS_POR_ROL[r] : [];
  });

  login(credentials: { correo: string; contrasena: string }): Observable<Usuario> {
    return this.http.post<any>(`${this.apiUrl}/login/`, credentials).pipe(
      map((res) => {
        const u = this.construirUsuario(res);
        if (!u) throw new Error('La respuesta del servidor no incluye un rol válido.');
        return u;
      }),
      tap((u) => this.guardar(u))
    );
  }

  /** Pregunta al backend quién es el usuario de la sesión (fuente de verdad del rol). */
  refrescarSesion(): Observable<Usuario | null> {
    return this.http.get<any>(`${this.apiUrl}/me/`).pipe(
      map((res) => this.construirUsuario(res)),
      tap((u) => (u ? this.guardar(u) : this.limpiar())),
      catchError(() => {
        this.limpiar();
        return of(null);
      })
    );
  }

  logout(): Observable<unknown> {
    return this.http.post(`${this.apiUrl}/logout/`, {}).pipe(
      catchError(() => of(null)),
      tap(() => this.limpiar())
    );
  }

  /** Limpia el estado local (también lo usa el interceptor ante 401). */
  limpiar(): void {
    this._usuario.set(null);
    try { sessionStorage.removeItem(STORAGE_KEY); } catch {}
  }

  tieneRol(...roles: Rol[]): boolean {
    const r = this.rol();
    return r !== null && roles.includes(r);
  }

  tienePermiso(...requeridos: Permiso[]): boolean {
    const mios = this.permisos();
    return requeridos.every((p) => mios.includes(p));
  }

  rutaInicial(): string {
    const r = this.rol();
    return r ? RUTA_INICIAL_POR_ROL[r] : '/login';
  }

  // ---- internos ----
  private construirUsuario(res: any): Usuario | null {
    const rol = normalizarRol(res?.rol ?? res?.usuario?.rol);
    if (!rol) return null;
    const src = res?.usuario ?? res;
    return { id: src.id_usuario ?? src.id ?? 0, nombre: src.nombre ?? '', rol };
  }

  private guardar(u: Usuario): void {
    this._usuario.set(u);
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify(u)); } catch {}
  }

  private leerGuardado(): Usuario | null {
    try {
      const raw = sessionStorage.getItem(STORAGE_KEY);
      if (!raw) return null;
      const p = JSON.parse(raw);
      const rol = normalizarRol(p?.rol);
      return rol ? { id: p.id, nombre: p.nombre, rol } : null;
    } catch {
      return null;
    }
  }
}
